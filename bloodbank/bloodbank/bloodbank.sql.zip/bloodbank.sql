-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2020 at 06:10 PM
-- Server version: 5.5.36
-- PHP Version: 5.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloodgroup`
--

CREATE TABLE IF NOT EXISTS `bloodgroup` (
  `B_GROUP` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodgroup`
--

INSERT INTO `bloodgroup` (`B_GROUP`) VALUES
('A+'),
('O+'),
('B+'),
('AB+'),
('A-'),
('O-'),
('B-'),
('AB-');

-- --------------------------------------------------------

--
-- Table structure for table `bloodrequest`
--

CREATE TABLE IF NOT EXISTS `bloodrequest` (
  `R_ID` int(11) NOT NULL AUTO_INCREMENT,
  `D_ID` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `U_NAME` varchar(30) NOT NULL,
  `U_CONTACT` bigint(30) NOT NULL,
  `B_GROUP` varchar(11) NOT NULL,
  `NOFUNIT` int(11) NOT NULL,
  `B_DATE` date NOT NULL,
  `U_EMAIL` varchar(30) NOT NULL,
  `H_ADDRESS` varchar(40) NOT NULL,
  `STATUS` varchar(30) NOT NULL,
  PRIMARY KEY (`R_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `bloodrequest`
--

INSERT INTO `bloodrequest` (`R_ID`, `D_ID`, `ID`, `U_NAME`, `U_CONTACT`, `B_GROUP`, `NOFUNIT`, `B_DATE`, `U_EMAIL`, `H_ADDRESS`, `STATUS`) VALUES
(10, 2, 9, 'Ohm Krishna', 1234561234, 'B+', 2, '2020-04-15', 'ohmi@gmail.com', 'Renai Medicity\r\nKottayam', 'Requested'),
(11, 3, 11, 'Anusha Raj', 9876543215, 'A+', 2, '2020-04-03', 'anusha@gmail.com', 'Revel Hospital\r\nasdfghjzxcvbnaesdfgh\r\nas', 'Requested');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `C_ID` int(11) NOT NULL AUTO_INCREMENT,
  `C_DATE` date NOT NULL,
  `C_NAME` varchar(30) NOT NULL,
  `C_EMAIL` varchar(30) NOT NULL,
  `TEXT` varchar(60) NOT NULL,
  PRIMARY KEY (`C_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`C_ID`, `C_DATE`, `C_NAME`, `C_EMAIL`, `TEXT`) VALUES
(1, '2020-03-09', 'Aiswarya K M', 'achu@gmail.com', 'azdsxfcgvhbjn'),
(2, '2020-03-28', 'Sarfraz Jord', 'sarfraz@gmail.com', 'Need B+ blood urgent for a girl \r\ndate: 21-04-2020');

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
  `DISTRICT` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`DISTRICT`) VALUES
('Thiruvanandapuram'),
('Kollam'),
('Pathanamthitta'),
('Alapuzha'),
('Kottayam'),
('Idukki'),
('Ernakulam'),
('Thrissur'),
('Palakkadu'),
('Malappuram'),
('Kozhikkodu'),
('Vayanadu'),
('Kannur'),
('Kasargodu');

-- --------------------------------------------------------

--
-- Table structure for table `donarregistration`
--

CREATE TABLE IF NOT EXISTS `donarregistration` (
  `ID` int(11) NOT NULL,
  `D_ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE` date NOT NULL,
  `D_NAME` varchar(30) NOT NULL,
  `DOB` date NOT NULL,
  `AGE` int(11) NOT NULL,
  `D_ADDRESS` varchar(30) NOT NULL,
  `CONTACT` bigint(30) NOT NULL,
  `BLOODGROUP` varchar(11) NOT NULL,
  `HEIGHT` int(11) NOT NULL,
  `WEIGHT` int(11) NOT NULL,
  `STATUS` varchar(30) NOT NULL,
  PRIMARY KEY (`D_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `donarregistration`
--

INSERT INTO `donarregistration` (`ID`, `D_ID`, `DATE`, `D_NAME`, `DOB`, `AGE`, `D_ADDRESS`, `CONTACT`, `BLOODGROUP`, `HEIGHT`, `WEIGHT`, `STATUS`) VALUES
(8, 2, '2020-03-28', 'Nima Vargheeze', '1998-06-22', 21, 'Thalayolaparambil(H)\r\nEdavanak', 1234567890, 'B+', 146, 51, 'Registered'),
(10, 3, '2020-03-28', 'Wreck n H', '1997-01-27', 23, 'Devils House\r\nGostenberg villa', 6668887771, 'A+', 150, 49, 'Registered');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `TYPE` varchar(11) NOT NULL,
  `USER_ID` varchar(30) NOT NULL,
  `PASSWORD` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`TYPE`, `USER_ID`, `PASSWORD`) VALUES
('admin', 'admin', 'admin'),
('admin', 'admin', 'admin'),
('customer', '', ''),
('customer', 'nimaloo', 'nimaloo'),
('customer', 'krishna', 'ohmkrishna'),
('customer', 'wrecknh', 'wrecknh'),
('customer', 'anusharaj', 'anusha123');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `DATE` date NOT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(30) NOT NULL,
  `ADDRESS` varchar(60) NOT NULL,
  `GENDER` varchar(10) NOT NULL,
  `CONTACT` bigint(30) NOT NULL,
  `DISTRICT` varchar(30) NOT NULL,
  `EMAIL` varchar(30) NOT NULL,
  `USER_NAME` varchar(30) NOT NULL,
  `PASSWORD` varchar(30) NOT NULL,
  `STATUS` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`DATE`, `ID`, `NAME`, `ADDRESS`, `GENDER`, `CONTACT`, `DISTRICT`, `EMAIL`, `USER_NAME`, `PASSWORD`, `STATUS`) VALUES
('2020-03-28', 8, 'Nima Vargheeze', 'NimaVargheeze\r\nThayyolaparabil(H)\r\nEdavanakadu po\r\nEdavanaka', 'female', 1234567890, 'Ernakulam', 'nimu@gmail.com', 'nimaloo', 'nimaloo', 'Registered'),
('2020-03-28', 9, 'Ohm Krishna', 'Omar house\r\nAgori villa\r\nThottakayam po', 'male', 1234561234, 'Kottayam', 'ohmi@gmail.com', 'krishna', 'ohmkrishna', 'Registered'),
('2020-03-28', 10, 'Wreck n H', 'Devils House\r\nGostenberg villa\r\nVampire Street', 'female', 6668887771, 'Malappuram', 'wrecknh@gmail.com', 'wrecknh', 'wrecknh', 'Registered'),
('2020-03-28', 11, 'Anusha Raj', 'Abcvghy House\r\nRiyad avenue\r\nPalarivattam\r\n', 'female', 9876543215, 'Kottayam', 'anusha@gmail.com', 'anusharaj', 'anusha123', 'Registered');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
